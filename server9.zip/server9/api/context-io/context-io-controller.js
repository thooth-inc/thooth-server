module.exports.controller = function (app) {
    var MCEBrandsModule = require('./brands-module');
    var users = require('./users-module');
    var fs = require('fs');
    var _ = require('lodash');
    var ContextIO = require('contextio');
    var contextio_token = "";
    var account_id = "";

    /**
     * @author
     * @description Following variable is used to access context.io APIs using OAuth 1.0.
     *              'key'' & 'secret'' should be updated after UAT sign off for 
     *              the new context.io account created for the client.  
     */
    var ctxioClient = ContextIO({
        key: "v5u6g6dd",
        secret: "decoUxEAgm0w3njJ",
        version: "2.0"
    });

    /**
     * @author
     * @description Used to delete a context.io account if user has deleted the 
     *              account from his/her configured accounts.
     */
    function deleteCTXAccount(emailid) {
        ctxioClient.accounts().get({ email: emailid }).then(function (account) {
            var accounts = account;
            var counter = 0;
            if (accounts.length > 0) {
                accounts.forEach(function (currentValue, index, arr) {
                    ctxioClient.accounts(currentValue.id).delete().then(function (deletedAccount) {
                        counter++;
                    }).catch(function (err) {
                        console.log(err);
                    });
                }, this);
                console.log({
                    message: "Account deleted"
                });
            } else {
                console.log('No account');
            }

        }).catch(function (err) {
            response.send(err);
            console.log(err);
        })
    }

    return {
        index: function (req, res, next) {
            res.send(req.body);
            next();
        },

        /**
         * @author
         * @description Method to get accounts based on unique userId & primaryEmail.
         */
        getAccounts: function (req, res) {

            var userDetails = JSON.parse(req.body.userDetails);
            var Accounts = [];
            users.find({ userId: userDetails.userID, primaryEmail: userDetails.primaryEmail }, function (err, user) {
                var userObject = null;
                if (user[0] && user[0]._doc) {
                    userObject = user[0]._doc;
                    Accounts.push({
                        accountId: userObject.accountId,
                        emailId: userObject.primaryEmail,
                        provider: userObject.provider,
                        isPrimary: true
                    });
                    userObject.connectedAccounts.forEach(function (element) {
                        Accounts.push({
                            accountId: element.accountId,
                            emailId: element.emailId,
                            provider: element.provider,
                            isPrimary: false
                        });
                    }, this);
                }
                if (Accounts.length > 0) {
                    var groupedAccounts = _.groupBy(Accounts, 'provider');
                    res.send(groupedAccounts);
                }
                else
                    res.send([]);
            });
        },

        /**
         * @author
         * @description Method to get the details about the most recently added account to context.io with respect to connect_token. 
         */
        getCurrentAccount: function (req, res) {
            ctxioClient.connect_tokens(req.query.token).get().then(function (accountDetails) {
                res.send(accountDetails);
            });
        },

        /**
         * @author
         * @description Method to add new user account in application database.
         */
        addLocalAccount: function (req, res) {

            var userDetails = req.body.userDetails;
            var token = req.body.token;
            var primaryEmail = req.body.userDetails.primaryEmail;
            var userData = {};
            function getAccountType(email) {
                var emailType = email.substring(email.lastIndexOf("@") + 1, email.lastIndexOf("."));
                if(emailType != 'gmail' && emailType != 'yahoo' && emailType != 'outlook')
                    emailType = 'gmail';
                return emailType;
            };

            users.find({ userId: userDetails.userID }, function (err, user) {
                ctxioClient.connect_tokens(token).get().then(function (accountDetails) {
                    var emailID = accountDetails.account.sources[0].username;
                    if (user.length == 0) {
                        if (primaryEmail == '') {
                            userData = {
                                userId: req.body.userDetails.userID,
                                accountId: accountDetails.account.id,
                                primaryEmail: emailID,
                                provider: getAccountType(emailID),
                                connectedAccounts: []
                            }
                            var usersModel = new users(userData);
                            usersModel.save(function (err, savedUser) {
                                if (err) {
                                    res.send(err);
                                } else {
                                    res.send(savedUser);
                                }
                            });
                        }
                    } else {
                        if (primaryEmail != '') {
                            users.findOne({ 'userId': req.body.userDetails.userID, 'primaryEmail': req.body.userDetails.primaryEmail }, {}, {}, function (err, record) {
                                if (err) {
                                    res.send(err);
                                }
                                if (!record) {
                                    res.send('No matching record found');
                                } else {
                                    record.connectedAccounts.push({
                                        accountId: accountDetails.account.id,
                                        emailId: emailID,
                                        provider: getAccountType(emailID)
                                    });
                                    //Now, mongoose can't automatically detect that you've changed the contents of 
                                    //record.connectedAccounts, so tell it
                                    //see http://mongoosejs.com/docs/api.html#document_Document-markModified
                                    record.markModified('connectedAccounts');
                                    record.save(function (err, updatedUser) {
                                        if (err) {
                                            res.send(err);
                                        } else {
                                            res.send(updatedUser);
                                        }
                                    });
                                }
                            });
                        }
                    }

                }, function (err) {
                    res.send(err);
                });
            });

        },

        /** 
         * @author
         * @description Method to create an context.io account.  
         */
        addCtxAccount: function (req, res) {
            var requestParamsCIO = {
                email: req.body.email,
                callback_url: req.body.callback_url
            }
            ctxioClient.connect_tokens().post(requestParamsCIO).then(function (success) {
                console.log(success);
                res.send(success);
            }, function (err) {
                console.log(err);
                res.send({
                    error: true,
                    message: 'Error occured while creating Context.IO account!'
                });
            });
        },

        /**
         * @author
         * @description Method to get file URLs from context.io by providing the file id.
         * */

        getFile: function (req, res) {
            ctxioClient.accounts(req.query.accountId).files(req.query.fileId).content().get({ as_link: 1 }).then(function (fileUrl) {
                res.send({
                    error: false,
                    status: 200,
                    message: 'Displaying attachment',
                    fileUrl: fileUrl
                });
            }, function (error) {
                console.log(error);
                res.send({
                    error: true,
                    status: 404,
                    message: 'Error occured while displaying the attachment. Please try again later!',
                    fileUrl: ''
                });

            })
        },

        getBrands: function (req, res) {
            MCEBrandsModule.find({}, { brandId: 0, emailDetails: 0 }, function (err, results) {
                res.send(results);
            });
        },

        getDomains: function (req, res) {
            MCEBrandsModule.find({}, { brandId: 0, emailDetails: 0 }, function (err, results) {
                res.send(results);
            });
        },

        getSelectedBrandEmails: function (req, res) {
            MCEBrandsModule.find({ "brandName": req.query.brandName }, { emailDetails: 1 }, function (err, results) {
                if (err) {
                    console.log(err);
                }
                res.send(results);
            });
        },

        getMailsMatchingFromMail: function (req, res) {
            ctxioClient.accounts(req.query.accountId).messages().get({ from: req.query.email }).then(function (messageData) {
                res.send(messageData);
            }).catch(function (err) {
                console.log(err)
            })
        },

        /**
         * 
         */
        deleteAccount: function (req, res) {

            users.find({ userId: req.body.userId, accountId: req.body.accountId }, function (err, user) {
                if (user.length > 0) {
                    if (req.body.deletePrimary) {
                        //delete entire record                        
                        users.remove({ $and: [{ 'userId': req.body.userId, 'accountId': req.body.accountId }] }, function (err, results) {
                            if (err) {
                                console.log(err);
                            }
                            if (results) {
                                ctxioClient.accounts(req.body.accountId).delete().then(function (acknowledgement) {
                                    deleteCTXAccount(req.body.emailId);
                                    res.send({
                                        status: 200,
                                        message: 'Account deleted Successfully',
                                        primary: true
                                    });
                                }).catch(function (err) {
                                    console.log(err)
                                })
                            }
                        });

                    } else {
                        res.send({
                            status: 200,
                            message: 'You are trying to delete your account with primary email ' + user[0]._doc.primaryEmail,
                            primary: true
                        });
                    }

                } else {
                    //Update connected accounts
                    users.findOne({ userId: req.body.userId, connectedAccounts: { $elemMatch: { accountId: req.body.accountId } } }, function (err, record) {
                        console.log(record);
                        if (!record) {
                            res.send('No matching record found');
                        } else {
                            for (var i = 0; i < record._doc.connectedAccounts.length; i++) {
                                if (record._doc.connectedAccounts[i].accountId == req.body.accountId) {
                                    record._doc.connectedAccounts.splice(i);
                                }
                            }
                            deleteCTXAccount(req.body.emailId);
                            record.markModified('connectedAccounts');
                            record.save(function (err, updatedAccount) {
                                if (err) {
                                    res.send(err);
                                } else {
                                    res.send({
                                        status: 200,
                                        message: 'Account deleted Successfully',
                                        primary: false
                                    });
                                }
                            });

                        }
                    });
                }
            });
        },

        getMailsBody: function (req, res) {
            ctxioClient.accounts(req.query.accountId).messages(req.query.msgId).get({ include_body: 1, body_type: "text/html" }).then(function (messageData) {
                res.send(messageData);
            }).catch(function (err) {
                res.send(err);
                console.log(err);
            })
        },

        brandEmailDetails: function (req, res) {
            MCEBrandsModule.find({ "emailDetails.brandEmailId": req.query.email }, { emailDetails: 1 }, function (err, results) {
                if (err) {
                    res.send(err);
                    console.log(err);
                }
                res.send(results);
            });
        },

        emailTypeImages: function (request, response) {
            var fileName = request.query.imageId;
            var path = "api/uploads/emails/";
            path = path + fileName + ".png";
            var img = fs.readFileSync(path);
            response.contentType("image/png");
            response.send(img);
        },

        brandImages: function (request, response) {
            var fileName = request.query.brandIcon;
            var path = "api/uploads/brands/";
            path = path + fileName + ".png";
            var img = fs.readFileSync(path);
            response.contentType("image/png");
            response.send(img);
        },

        getContextIoAccount: function (request, response) {
            ctxioClient.accounts().get({ email: request.query.email }).then(function (account) {
                var accounts = account;
                var counter = 0;
                if (accounts.length > 0) {
                    accounts.forEach(function (currentValue, index, arr) {
                        ctxioClient.accounts(currentValue.id).delete().then(function (deletedAccount) {
                            counter++;
                        }).catch(function (err) {
                            response.send(err);
                        });
                    }, this);
                    console.log({
                        message: "Account deleted"
                    });
                } else {
                    console.log('No account');
                }

            }).catch(function (err) {
                response.send(err);
                console.log(err);
            })
        }
    }
}