var mongoose = require('mongoose');
/**
 * Schema for marriott brands
 */
var thoothDomain = mongoose.Schema({
    domainName: String,
    domainId: String,
    domainIcon: String,
    emailDetails: [{
            domainEmailId: String,
            emailType: String,
            imageId: String
    }]
});

module.exports = mongoose.model('thooth_brands', thoothDomain);