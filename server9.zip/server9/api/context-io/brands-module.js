var mongoose = require('mongoose');
/**
 * Schema for marriott brands
 */
var marriottBrands = mongoose.Schema({
    brandName: String,
    brandId: String,
    brandIcon: String,
    emailDetails: [{
            brandEmailId: String,
            emailType: String,
            imageId: String
    }]
});

module.exports = mongoose.model('branddetails', marriottBrands);