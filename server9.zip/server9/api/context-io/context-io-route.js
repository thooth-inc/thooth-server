module.exports = function (app) {

    var csController = require('./context-io-controller').controller(app);

    /**
     * Base path for each API
     */
    var BASE = "/marriott";

    /**
     * Api to check health of the controller
     */
    app.get(BASE + '/index', csController.index);

    /**
     * Apis to manipulate accounts component related data
     */
    app.get(BASE + '/getContextIoAccount', csController.getContextIoAccount);
    app.post(BASE + '/accounts', csController.getAccounts);
    app.post(BASE + '/addLocalAccount', csController.addLocalAccount);
    app.post(BASE + '/account/add', csController.addCtxAccount);
    app.get(BASE + '/getCurrentAccount', csController.getCurrentAccount);
    app.put(BASE + '/account/delete', csController.deleteAccount);

    /**
     * Apis to manipulate brands component related data
     */
    app.get(BASE + '/brands', csController.getBrands);
    app.get(BASE + '/sites', csController.getDomains);
    app.get(BASE + '/brandEmailDetails', csController.brandEmailDetails);
    app.get(BASE + '/brands/images', csController.brandImages);

    /**
     * APIs to manipulate email component related data
     */
    app.get(BASE + '/emails/messagebody', csController.getMailsBody);
    app.get(BASE + '/getFile', csController.getFile);
    app.get(BASE + '/emails', csController.getMailsMatchingFromMail);
    app.get(BASE + '/brand/details', csController.getSelectedBrandEmails);
    app.get(BASE + '/emailTypeImages', csController.emailTypeImages);
    app.get(BASE + '/emails/messagebody', csController.getMailsBody);
}
