var mongoose = require('mongoose');
/**
 * User model to handle different users related to our application
 */
var users = mongoose.Schema({
    userId: String,
    accountId: String,
    provider: String,
    primaryEmail : String,
    connectedAccounts: Array
});

module.exports = mongoose.model('users', users);
